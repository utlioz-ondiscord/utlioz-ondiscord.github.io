#Killer-Jeff-for-html
Abusing users' trust in cookie policy banners since 2021.
Use it to scare your friends!They'll love it.
